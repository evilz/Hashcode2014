﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrialRound.Extentions;

namespace QualificationTask
{
    class Program
    {
        private static void Main(string[] args)
        {
            const string FILE_NAME = @"Samples/dc.in";


            StringBuilder sbOut = new StringBuilder();

            using (var inputStream = File.OpenRead(FILE_NAME))
            {
                var reader = new StreamReader(inputStream);

                // parse first line to get Matrix Size
                var inputInt = reader.ExtractValues<int>().ToArray();

            var rows = inputInt[0];
            var slotseach = inputInt[1];
            var slotunavailable = inputInt[2];
            var pool = inputInt[3];
            var servers = inputInt[4];

            
                reader.Close();
                inputStream.Close();
            }
        }

    }
}
